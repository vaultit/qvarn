__version__ = "0.30+git"
__version_info__ = (0, 30, '+git')
