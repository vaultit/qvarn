__version__ = "1.20170823+git"
__version_info__ = (1, 20170823, '+git')
